package com.example.internettest



import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL


class MainActivity : AppCompatActivity() {
    private val link = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=ff49fcd4d4a08aa6aafb6ea3de826464&tags=cat&format=json&nojsoncallback=1"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnHTTP: Button = findViewById(R.id.btnHTTP)
        val btnOkHTTP: Button = findViewById(R.id.btnOkHTTP)

        btnOkHTTP.setOnClickListener {
            getDataOkhttp()
        }

        btnHTTP.setOnClickListener {
            Thread(Runnable {
                    val url = URL(link)
                    val urlConnection = url.openConnection() as HttpURLConnection
                    try {
                        val text = BufferedInputStream(urlConnection.inputStream)
                        val data: String = readStream(inputStream = text)
                        Log.d("Flickr cats",data )
                    } catch (e: IOException) {
                    } finally {
                        urlConnection.disconnect()
                    }
                }).start()
            }

        }


        fun readStream(inputStream: BufferedInputStream): String {
            val bufferedReader = BufferedReader(InputStreamReader(inputStream))
            val stringBuilder = StringBuilder()
            bufferedReader.forEachLine { stringBuilder.append(it) }
            return stringBuilder.toString()
        }

        fun getDataOkhttp(){
           val request = Request.Builder()
                    .url(link)
                    .build()
           val client = OkHttpClient()
           client.newCall(request).enqueue(object: Callback{
               override fun onFailure(call: Call, e: IOException) {
                   Log.e("Failed", e.message.toString())
               }

               override fun onResponse(call: Call, response: Response) {
                  val body = response.body()
                   Log.i("Flickr cats",body!!.string())
               }

           })
    }


 }



