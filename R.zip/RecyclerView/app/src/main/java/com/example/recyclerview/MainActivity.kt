package com.example.recyclerview

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class ColorData(
    val colorName: String,
    val colorHex: Int
)
interface CellClickListener {
    fun onCellClickListener(data: ColorData)
}
class Adapter(private val context: Context,
              private val arrayList: ArrayList<ColorData>,
              private val cellClickListener: CellClickListener): RecyclerView.Adapter<Adapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val colorTv: View = view.findViewById(R.id.view)
        val titleTv: TextView = view.findViewById(R.id.textView)

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rview_item,parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = arrayList[position]
        holder.colorTv.setBackgroundColor(data.colorHex)
        holder.titleTv.text = data.colorName
        holder.itemView.setOnClickListener {
            cellClickListener.onCellClickListener(data)
        }
    }}
    class MainActivity : AppCompatActivity() , CellClickListener {


        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            val recyclerView: RecyclerView = findViewById(R.id.rView)
            val arrayList = ArrayList<ColorData> ()

            arrayList.add(ColorData("WHITE", Color.WHITE))
            arrayList.add(ColorData("BLACK", Color.BLACK))
            arrayList.add(ColorData("BLUE", Color.BLUE))
            arrayList.add(ColorData("RED", Color.RED))
            arrayList.add(ColorData("MAGENTA", Color.MAGENTA))

            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = Adapter(this,   arrayList,this)
            recyclerView.setHasFixedSize(true)
            recyclerView.addItemDecoration(DividerItemDecoration(this,RecyclerView.VERTICAL))

        }

        override fun onCellClickListener(data: ColorData) {
            Toast.makeText( this,  "IT'S  " +data.colorName.toString(), Toast.LENGTH_SHORT).show()
        }

    }


